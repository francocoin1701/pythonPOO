from setuptools import setup

setup(
    name = "paqueteNombre",
    version = "1.0",
    description = "una descripcion del paquete a compartir",
    author = "franco",
    author_email = "franco@gmail.com",
    url = "www.franco.com",
    packages = ["funciones"]
)