#este es un modulo de las funciones matematicas para la practica de el lenguaje de programacion python

def suma(opc1,opc2):
    print("el resultado de la suma es: ", opc1 + opc2)

def resta(opc1,opc2):
    print("el resultado de la resta es: ",opc1 - opc2)

def multiplicacion(opc1, opc2):
    print("el resultado de la multiplicacion es: ",opc1*opc2)

def divicion(opc1,opc2):
    print("el resultado de la divicion es: ",opc1/opc2)            

