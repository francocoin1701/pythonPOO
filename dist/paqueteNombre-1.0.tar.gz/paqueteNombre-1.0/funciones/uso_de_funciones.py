from funciones_matematicas import *

suma(4,5)
resta(9,10)
multiplicacion(30,0)
divicion(7,1)